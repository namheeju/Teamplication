import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class SocketServer {
   public static void main(String[] args){
      try{
         int portNumber = 5517;
         
         System.out.println("starting socket server");
         ServerSocket aServerSocket = new ServerSocket(portNumber);
         System.out.println("Listening at port" + portNumber + "...");
         
         while(true){
            Socket sock = aServerSocket.accept();
            InetAddress clientHost = sock.getLocalAddress();
            int ClientPort = sock.getPort();
            System.out.println("A client connected. host: " + clientHost + ", port : "+ClientPort);
            
       
            
            ObjectInputStream instream = new ObjectInputStream(sock.getInputStream());
            Object obj = instream.readObject();
            System.out.println("Input:"+obj);
            
            ObjectOutputStream outstream = new ObjectOutputStream(sock.getOutputStream());
            outstream.writeObject(obj + " from Server ");
            
            UserServiceHandler ush = new UserServiceHandler();
            ush.socketRead(obj, sock);
            
            /*
            String message = obj.toString();
            
 
            if(message.equals("UserService")){
               UserServiceHandler ush = new UserServiceHandler();
                ush.socketRead(obj, sock);
            }
            */
            outstream.flush();
            
            sock.close();
            
         }
      }catch(Exception ex){
         ex.printStackTrace();
      }
   }

}