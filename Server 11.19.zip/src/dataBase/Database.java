package dataBase;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Database{
   public static final String driver = "org.mariadb.jdbc.Driver";
   public static final String connection = "jdbc:mariadb://localhost:3306/teamplication";
   public static final String id = "root";
   public static final String pass = "se";
   
   private static Connection conn = null;

   private static DatabaseConnector connManager;
   /**
    * Necessary to initialize the object DataBase access
    */
   public static Connection Connector(){
      try{
         connManager = new DatabaseConnector(driver, connection, id, pass);
         conn = connManager.createConnection();
         return conn;
      }
      catch(SQLException e){
         System.out.println("DB Connection Error + "+e);
         e.printStackTrace();
         connManager = null;
         return null;
      }
   }
   /**
    * Schedule time to update the use of renewable energy
    * @param schedule   Point-of-use renewable energy.
    */
}
 