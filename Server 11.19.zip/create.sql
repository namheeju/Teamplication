drop database teamplication;
create database teamplication;
use teamplication;
create table test(
	test	    INT NOT NULL
);