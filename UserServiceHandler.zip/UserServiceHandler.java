
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import Mapper.AccountMapper;

public class UserServiceHandler {

   protected int port = 5111;
   protected String hostname= "172.30.1.55";

   AccountMapper acountMapper = new AccountMapper();

   public void socketRead(Socket socket){
      try{
        // Socket socket = new Socket(hostname,port);
         ObjectInputStream instream = new ObjectInputStream(socket.getInputStream());
         Object obj = instream.readObject();
         
         String message=obj.toString();
         System.out.println(obj);
         
         if(message.startsWith("@getUser_id")){
            String[] user = message.substring(11).split(" ");
            String ID = user[0];
            
            String out = acountMapper.getUser(ID);
            
            if(out==null){
               ObjectOutputStream outstream = new ObjectOutputStream(socket.getOutputStream());
                  outstream.writeObject(null);
                  outstream.flush();
                  socket.close();
            }
            else{
             ObjectOutputStream outstream = new ObjectOutputStream(socket.getOutputStream());
               outstream.writeObject(out);
               outstream.flush();
               socket.close();
            }
         }
         
         else if(message.startsWith("@getUser_id_nickname")){
            String[] user = message.substring(20).split(" ");
            String ID = user[0];
            String Nickname = user[1];
            
            String out = acountMapper.getUser(ID, Nickname);
            
             ObjectOutputStream outstream = new ObjectOutputStream(socket.getOutputStream());
               outstream.writeObject(out);
               outstream.flush();
               socket.close();
         }
         
         else if(message.startsWith("@addUser")){
            
            String[] user = message.substring(8).split(" ");
            String ID = user[0];
            String Nickname = user[1];
            
            acountMapper.addUser(ID, Nickname);
            
              socket.close();
         }
         
         /*
         else if(message.startsWith("@updateUser")){
            
            String[] user = message.substring(11).split(" ");
            String ID = user[0];
            String Nickname = user[1];
            String Description = user[2];
            
            acountMapper.updateUser(ID, Nickname);
              socket.close();
         }
         */
      }catch(Exception e){}

   }
}