package Mapper;

import dataBase.Database;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class AccountMapper {
   public static int NO=0;

   private Connection conn;
   private ResultSet rs;

   
   public String getUser(String ID){//getUser(ID)
      String result = null;
      try{
         Statement stmt = Database.Connector().createStatement();         
         rs= stmt.executeQuery("select * from t_user where ID='"+ID+"';");
         result=rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4);
         return result;
   }
      
      catch(SQLException ex){
         return null;
      }
   }
   
   public String getUser(String ID,String Nickname){//getUser(ID,Nickname)
      String result = null;
      try{
         Statement stmt = Database.Connector().createStatement();         
         rs= stmt.executeQuery("select * from t_user where ID='"+ID+"'Nickname='"+Nickname+"';");
         result=rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4);
         return result;
   }
      
      catch(SQLException ex){
         return null;
      }
   }
   public String addUser(String ID, String Nickname){//addUser(ID,Nickname)
      String result = null;
      try{
         Statement stmt = Database.Connector().createStatement();         
         rs = stmt.executeQuery("select * from t_user where ID='"+ID+"';");
         if(rs.next()){
            rs.close();
            stmt.close();
            conn.close();
      
            return null;
         }
         else{
            rs.close();
            stmt.close();
            conn.close();
            rs= stmt.executeQuery("insert into t_user values('"+(NO++)+"','"+ID+"','"+Nickname+"');");
            result=rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3);
            return result;
         }
      }
      catch(SQLException ex){
            return null;
         }

   
   }
   public String updateUser(String ID, String Nickname, String Description){//updateUser(ID,Nickname,Description)
      String result = null;
      try{
         Statement stmt = Database.Connector().createStatement();      
         rs = stmt.executeQuery("select * from t_user where ID='"+ID+"';");
         if(rs.next()){
            rs.close();
            stmt.close();
            conn.close();
            rs= stmt.executeQuery("update t_user set id;");
            result=rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3);
            return null;
         }
         else{
            rs.close();
            stmt.close();
            conn.close();
            
            return result;
         }
      
         
      }
      catch(SQLException ex){
         return null;
      }
   }
}