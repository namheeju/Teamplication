package Mapper;

import dataBase.Database;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class AccountMapper {

	private Connection conn;
	private ResultSet rs;

	
	public boolean checkID(String Cid) {				//ID �ߺ��˻�
		try {
			Statement stmt = Database.Connector().createStatement();
			rs = stmt.executeQuery("select * from Account where ID='"+Cid+"';");
			if(rs.next()){
				rs.close();
				stmt.close();
				conn.close();
				
				return false;
			}
			else{
				rs.close();
				stmt.close();
				conn.close();
				
				return true;
			}
			
		} catch (SQLException ex) {
		}
		return false;
	}

	public boolean createAccount(String Cid, String Cpw, String Cname,int Cbirth, String Cphone,String Cemail){	//ȸ������
		try {
			Statement stmt = Database.Connector().createStatement();
			rs = stmt.executeQuery("insert into Account values('"+Cid+"','"+Cpw+"','"+Cname+"',"+Cbirth+",'"+Cphone+"','"+Cemail+"');");
			rs.close();
			stmt.close();
			conn.close();
			return true;
		} catch (SQLException ex) {
			return false;
		}
		
	}
		
	public String login(String Cid, String Cpw){			//�α���
		String result;
		try{
			Statement stmt = Database.Connector().createStatement();			
			rs= stmt.executeQuery("select * from Account where ID='"+Cid+"', PW='"+Cpw+"';");
			if(rs.next()){
				result=rs.getString(3)+" "+rs.getInt(4)+" "+rs.getString(5)+" "+rs.getString(6);
				return result;
			}
			else{
				return null;
			}
		}catch(SQLException ex){
			return null;
		}
		
	}
	  

}
