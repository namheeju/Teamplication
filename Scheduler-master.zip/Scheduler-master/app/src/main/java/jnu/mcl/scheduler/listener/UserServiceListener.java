package jnu.mcl.scheduler.listener;

/**
 * Created by 김 on 2015-11-29.
 */
public interface UserServiceListener {

    void onUserUpdate();
}
