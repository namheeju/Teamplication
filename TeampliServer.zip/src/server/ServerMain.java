package server;

public class ServerMain {
	public static Teamplication_Server ds;

	public static void main(String[] args) {
		ds = new Teamplication_Server(8082);
		try {
			ds.listen(); // Start listening for connections
		} catch (Exception ex) {
			System.out.println("ERROR - Could not listen for clients!");
		}
	}
}