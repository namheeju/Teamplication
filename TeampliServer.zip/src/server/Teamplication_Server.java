package server;

import java.io.IOException;
import IO.Database;

public class Teamplication_Server extends AbstractServer {
	int turn = 1;

	public Teamplication_Server(int port) {
		super(port);
		// TODO Auto-generated constructor stub
	}

	protected void handleMessageFromClient(Object msg, ConnectionToClient client) {
		// TODO Auto-generated method stub
		System.out.println("handle");
		Database db = new Database();
		String rs = null;
		String m = msg.toString();
		switch (m) {
		default:
			if (m.startsWith("@UserList")) {
				rs = db.getUser();
				try {
					client.sendToClient("@UserList" + rs);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (m.startsWith("@SignUp")) {
				System.out.println("SignUp");
				m = m.substring(7); // id
				System.out.println(m);
				rs = db.getUser(m);
				try {
					client.sendToClient("@getUser_id" + rs);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			if (m.startsWith("@Login")) {
				m = m.substring(6);
				String[] n = m.split("!"); // id, nickname 쪼갬
				rs = db.getUser(n[0], n[1]);
				try {
					client.sendToClient("@@getUser_id_nickname" + rs);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (m.startsWith("@Add")) {
				System.out.println("Add");
				m = m.substring(4);
				String[] n = m.split("!"); // id, nickname 쪼갬
				System.out.println(n[0] + "  " + n[1]);
				rs = db.addUser(n[0], n[1]);
				try {
					client.sendToClient(rs);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (m.startsWith("@Update")) {
				m = m.substring(7);
				String[] n = m.split("!"); // id, nickname 쪼갬 또는 id, nickname,
											// description 쪼갬
				rs = db.updateUser(n[0], n[1], n[2]);
				try {
					client.sendToClient(rs);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (m.startsWith("#GetCalendar")) {
				m = m.substring(12);
				rs = db.getCalendar(m);
				try {
					client.sendToClient("#GetCalendar" + rs); // *
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (m.startsWith("#CalendarList")) {
				m = m.substring(13);
				rs = db.getCalendar();
				try {
					client.sendToClient("#CalendarList" + rs);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (m.startsWith("#AddCalendar")) {
				m = m.substring(12);
				String[] n = m.split("!"); // account name , account type ,
											// name, calendar display name
				rs = db.addCalendar(n[0], n[1], n[2], n[3]);
				try {
					client.sendToClient(rs);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (m.startsWith("#UpdateCalendar")) {
				m = m.substring(15);
				String[] n = m.split("!"); // Calendar No , name
				rs = db.updateCalendar(n[0], n[1]);
				try {
					client.sendToClient(rs);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (m.startsWith("#DeleteCalendar")) {
				m = m.substring(15);
				rs = db.updateCalendar(m); // Calendar NO
				try {
					client.sendToClient(rs);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (m.startsWith("$EventList")) {
				m = m.substring(10);
				rs = db.getEventList();
				try {
					client.sendToClient("@EventList" + rs);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (m.startsWith("$$EventList_Calendar_NO")) {
				m = m.substring(23);
				rs = db.getEventList(m);
				try {
					client.sendToClient("@EventList" + rs);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (m.startsWith("$$$EventList_Now")) {
				m = m.substring(16);
				String[] n = m.split("!"); // Now , TodayEnd
				rs = db.getTodayEventList(n[0], n[1]);
				try {
					client.sendToClient("@EventList" + rs);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (m.startsWith("$GetEvent")) {
				m = m.substring(9);
				rs = db.getEvent(m); // event_no
				try {
					client.sendToClient("@GetEvent" + rs);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (m.startsWith("$AddEvent1")) {
				m = m.substring(10);
				String[] n = m.split("!"); // Calendar_No , Title , dtStart
				rs = db.addEvent(n[0], n[1], n[2]);
				try {
					client.sendToClient(rs);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (m.startsWith("$$AddEvent2")) {
				m = m.substring(11);
				String[] n = m.split("!"); // Calendar_No , Title , dtStart ,
											// dtEnd
				rs = db.addEvent(n[0], n[1], n[2], n[3]);
				try {
					client.sendToClient(rs);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (m.startsWith("$UpdateEvent")) {
				m = m.substring(12);
				String[] n = m.split("!"); // Event NO , Title , dtStart , dtEnd
				rs = db.updateEvent(n[0], n[1], n[2], n[3]);
				try {
					client.sendToClient(rs);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (m.startsWith("$DeleteEvent")) {
				m = m.substring(12); // Event NO
				rs = db.deleteEvent(m);
				try {
					client.sendToClient(rs);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			break;
		}
	}

	/**
	 * Hook method called each time a new client connection is accepted. The
	 * default implementation does nothing.
	 * 
	 * @param client
	 *            the connection connected to the client.
	 */
	protected void clientConnected(ConnectionToClient client) {
		System.out.println("Connected~");
	}

	/**
	 * This method overrides the one in the superclass. Called when the server
	 * starts listening for connections.
	 */
	protected void serverStarted() {
		System.out.println("" + getPort() + "");
	}

	/**
	 * This method overrides the one in the superclass. Called when the server
	 * stops listening for connections.
	 */
	protected void serverStopped() {
		System.out.println("");
	}

}
