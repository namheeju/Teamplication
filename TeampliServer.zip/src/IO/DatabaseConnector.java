package IO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnector {

	String driver = null;
	String connection = null;
	String user;
	String passwd;
	Connection conn;

	/**
	 * Initialize the needed variables in DataBase access
	 * 
	 * @param _driver
	 *            connection driver
	 * @param _connection
	 *            Database ip, port
	 * @param _user
	 *            Database id
	 * @param _passwd
	 *            Database password
	 * @throws SQLException
	 */

	public DatabaseConnector(String _driver, String _connection, String _user, String _passwd) throws SQLException {
		driver = _driver;
		connection = _connection;
		user = _user;
		passwd = _passwd;

		try {
			Class.forName(_driver);
		} catch (ClassNotFoundException e) {
			System.out.println("error " + e);
		}
	}

	/**
	 * Creates a connection object.
	 * 
	 * @return connection
	 * @throws SQLException
	 */
	public Connection createConnection() throws SQLException {
		conn = (Connection) DriverManager.getConnection(this.connection, this.user, this.passwd);
		return conn;
	}

	public void close() {
		try {
			conn.close();
		} catch (Exception e) {
			System.out.println("error " + e);
		}
	}
}