package IO;

import java.sql.SQLException;
import java.util.Date;

public class DBException extends SQLException {
	SQLException sqlException = null;
	String sql = "";
	String msg = "";
	String className = "";
	String methodName = "";
	Date dt = null;

	public DBException(SQLException se, String sql) {
		super(se.getMessage() + "(SQL : " + sql + ")");
		msg = se.getMessage();
		sqlException = se;
		this.sql = sql;
		setDate();
		sqlException.printStackTrace();
	}

	public DBException(SQLException se) {
		super(se.getMessage());
		this.msg = se.getMessage();
		this.sql = "";
		this.sqlException = se;
		setDate();
		sqlException.printStackTrace();
	}

	public DBException(SQLException se, String sql, Object classObj, String method) {
		this(se, sql);
		String cName = classObj.toString();
		int idx = cName.indexOf("@");
		this.className = cName.substring(0, idx);
		this.methodName = method;
	}

	public DBException(SQLException se, Object classObj, String method) {
		this(se);
		String cName = classObj.toString();
		int idx = cName.indexOf("@");
		this.className = cName.substring(0, idx);
		this.methodName = method;
	}

	public void setLocation(Object classObj, String method) {
		String cName = classObj.toString();
		int idx = cName.indexOf("@");
		this.className = cName.substring(0, idx);
		this.methodName = method;
	}

	public void setDate() {
		this.dt = new Date();
	}

	public String getErrorMessageHTMLTable(String align, int border, String bgColor, int cellpadding) {
		String strMessage = "";
		strMessage = "<table border='" + border + "' align='" + align + "' bgcolor='" + bgColor + "' cellpadding="
				+ cellpadding + "><BR>\n" + "<tr><td>" + getErrorMessageHTML() + "</td></tr>\n" + "<tr><td>"
				+ "<br><font color=magenta><b>위의 내용을 정보통신원 관리자에게 문의하시기 바랍니다</b></font>." + "</td></tr>\n"
				+ "</table>\n";
		return strMessage;
	}

	public String getErrorMessageHTMLTable() {
		return getErrorMessageHTMLTable("center", 0, "white", 0);
	}

	public String getErrorMessageHTML() {
		String strMessage = "<font color=blue>시간</font> : " + dt.toString() + "<br>\n"
				+ "<font color=blue>메세지</font> : " + msg + "<br>\n" + getErrorLocationHTML();
		return strMessage;
	}

	public String getErrorMessage() {
		String strMessage = "";
		strMessage = strMessage + "시  간 : " + dt.toString() + "\n";
		strMessage = strMessage + "메세지 : " + msg;
		if (!sql.equals(""))
			strMessage = strMessage + "\nSQL 문 : " + sql;
		return strMessage;
	}

	public String getErrorLocationHTML() {
		String strMessage = "";
		strMessage = strMessage + "<font color=blue>위치</font> :<br>\n";
		strMessage = strMessage + "&nbsp;&nbsp;&nbsp;&nbsp;<font color=blue>Method Name</font> : " + this.methodName
				+ "<br>\n";
		strMessage = strMessage + "&nbsp;&nbsp;&nbsp;&nbsp;<font color=blue>Class Name</font> : " + this.className
				+ "<br>\n";
		return strMessage;
	}
}
