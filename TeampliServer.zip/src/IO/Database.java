package IO;

import java.sql.*;

import IO.DatabaseConnector;
import IO.Database;

public class Database {
	public static final String driver = "org.mariadb.jdbc.Driver";
	public static final String connection = "jdbc:mysql://localhost:3306/teamplication";
	public static final String id = "root";
	public static final String pass = "0";
	private static Connection conn = null;
	private static DatabaseConnector connManager;
	public static int NO = 0;
	private ResultSet rs;

	public static Connection Connector() {
		try {
			connManager = new DatabaseConnector(driver, connection, id, pass);
			conn = connManager.createConnection();
			return conn;
		} catch (SQLException e) {
			System.out.println("DB Connection Error + " + e);
			e.printStackTrace();
			connManager = null;
			return null;
		}
	}

	public String getUser() {
		String result = "";
		try {
			Statement stmt = Connector().createStatement();
			rs = stmt.executeQuery("select * from t_user; ");

			String[] strColNm = null;
			int intColCnt = 0;
			// ----------------------------------
			// resultSet의 메타이타를 가져온다.
			// ----------------------------------
			ResultSetMetaData rMD = rs.getMetaData();
			// ----------------------------------
			// 컬럼의 항목을 가져온다.
			// ----------------------------------
			intColCnt = rMD.getColumnCount();
			strColNm = new String[intColCnt];
			for (int i = 0; i < intColCnt; i++) {
				strColNm[i] = rMD.getColumnName(i + 1).toLowerCase();
			}
			intColCnt = strColNm.length;

			while (rs.next()) {
				for (int i = 0; i < intColCnt; i++) {
					// result = rs.getInt(1) + " " + rs.getString(2) + " " +
					// rs.getString(3) + " " + rs.getString(4);
					result += " " + rs.getString(strColNm[i]);
				}
				result += " \n";
			}
			System.out.println("Return String : " + result);
			return result;
		} catch (SQLException ex) {
			return null;
		}
	}

	public String getUser(String ID) {
		// TODO Auto-generated method stub
		String result = null;
		try {
			Statement stmt = Connector().createStatement();
			rs = stmt.executeQuery("select * from t_user where ID='" + ID + "';");

			String[] strColNm = null;
			int intColCnt = 0;
			// ----------------------------------
			// resultSet의 메타이타를 가져온다.
			// ----------------------------------
			ResultSetMetaData rMD = rs.getMetaData();
			// ----------------------------------
			// 컬럼의 항목을 가져온다.
			// ----------------------------------
			intColCnt = rMD.getColumnCount();
			strColNm = new String[intColCnt];
			for (int i = 0; i < intColCnt; i++) {
				strColNm[i] = rMD.getColumnName(i + 1).toLowerCase();
			}
			intColCnt = strColNm.length;

			while (rs.next()) {
				for (int i = 0; i < intColCnt; i++) {
					// result = rs.getInt(1) + " " + rs.getString(2) + " " +
					// rs.getString(3) + " " + rs.getString(4);
					result += " " + rs.getString(strColNm[i]);
				}
				result += " \n";
			}
			System.out.println("Return String : " + result);
			return result;
		}

		catch (SQLException ex) {
			return null;
		}
	}

	public String getUser(String ID, String Nickname) {
		// TODO Auto-generated method stub
		String result = null;
		try {
			Statement stmt = Database.Connector().createStatement();
			rs = stmt.executeQuery("select * from t_user where ID='" + ID + "'Nickname='" + Nickname + "';");

			String[] strColNm = null;
			int intColCnt = 0;
			// ----------------------------------
			// resultSet의 메타이타를 가져온다.
			// ----------------------------------
			ResultSetMetaData rMD = rs.getMetaData();
			// ----------------------------------
			// 컬럼의 항목을 가져온다.
			// ----------------------------------
			intColCnt = rMD.getColumnCount();
			strColNm = new String[intColCnt];
			for (int i = 0; i < intColCnt; i++) {
				strColNm[i] = rMD.getColumnName(i + 1).toLowerCase();
			}
			intColCnt = strColNm.length;

			while (rs.next()) {
				for (int i = 0; i < intColCnt; i++) {
					// result = rs.getInt(1) + " " + rs.getString(2) + " " +
					// rs.getString(3) + " " + rs.getString(4);
					result += " " + rs.getString(strColNm[i]);
				}
				result += " \n";
			}
			System.out.println("Return String : " + result);
			return result;
		}

		catch (SQLException ex) {
			return null;
		}
	}

	public String addUser(String ID, String Nickname) {
		// TODO Auto-generated method stub
		String result = null;
		Statement stmt = null;

		try {
			stmt = Database.Connector().createStatement();
			rs = stmt.executeQuery("select * from t_user where ID='" + ID + "';");

			System.out.println("Database.addUserbefore insert :: exist check");

			int chkCnt = 0;
			while (rs.next()) {
				chkCnt++;
			}
			if (chkCnt > 0) {
				System.out.println("이미 존재하는 사용자입니다");

				return "이미 존재하는 사용자입니다";
			} else {
				String sql = "";
				sql = "insert into t_user ( NO, ID, Nickname, Description ) ";
				sql += "select ifnull(max(NO),0) + 1,'" + ID + "','" + Nickname + "', ''  ";
				sql += "  from t_user ";

				System.out.println("Database.addUser insert sql : " + sql);

				stmt = Database.Connector().createStatement();
				rs = stmt.executeQuery(sql);

				result = getUser(ID, Nickname);
				return result;
			}

		} catch (SQLException ex) {
			System.out.println("Database.addUserbefore SQLException");
			return null;
		} finally {
			System.out.println("Database.addUserbefore finally");
			try {
				rs.close();
			} catch (Exception ignored) {
			}
			try {
				stmt.close();
			} catch (Exception ignored) {
			}
			try {
				conn.close();
			} catch (Exception ignored) {
			}
		}

	}

	public String updateUser(String ID, String Nickname, String Description) {
		// TODO Auto-generated method stub
		String result = null;
		try {
			Statement stmt = Database.Connector().createStatement();
			rs = stmt.executeQuery("select * from t_user where ID='" + ID + "';");
			if (rs.next()) {
				rs.close();
				stmt.close();
				conn.close();
				rs = stmt.executeQuery("update t_user set ID='" + ID + "' Nickname='" + Nickname + "'Description='"
						+ Description + "');");
				result = rs.getInt(1) + " " + rs.getString(2) + " " + rs.getString(3) + " " + rs.getString(4);
				return result;
			} else {
				rs.close();
				stmt.close();
				conn.close();

				return null;
			}

		} catch (SQLException ex) {
			return null;
		}

	}

	public String getCalendar(String Calendar_no) {
		// TODO Auto-generated method stub
		String result = null;
		try {
			Statement stmt = Database.Connector().createStatement();
			rs = stmt.executeQuery("select * from t_calendar where Calendar_no ='" + Calendar_no + "';");

			String[] strColNm = null;
			int intColCnt = 0;
			// ----------------------------------
			// resultSet의 메타이타를 가져온다.
			// ----------------------------------
			ResultSetMetaData rMD = rs.getMetaData();
			// ----------------------------------
			// 컬럼의 항목을 가져온다.
			// ----------------------------------
			intColCnt = rMD.getColumnCount();
			strColNm = new String[intColCnt];
			for (int i = 0; i < intColCnt; i++) {
				strColNm[i] = rMD.getColumnName(i + 1).toLowerCase();
			}
			intColCnt = strColNm.length;

			while (rs.next()) {
				for (int i = 0; i < intColCnt; i++) {
					result += " " + rs.getString(strColNm[i]);
				}
				result += " \n";
			}
			System.out.println("Return String : " + result);
			return result;
		}

		catch (SQLException ex) {
			return null;
		}

	}

	public String getCalendar() {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		String result = null;
		try {
			Statement stmt = Database.Connector().createStatement();
			rs = stmt.executeQuery("select * from t_calendar ;");

			String[] strColNm = null;
			int intColCnt = 0;
			// ----------------------------------
			// resultSet의 메타이타를 가져온다.
			// ----------------------------------
			ResultSetMetaData rMD = rs.getMetaData();
			// ----------------------------------
			// 컬럼의 항목을 가져온다.
			// ----------------------------------
			intColCnt = rMD.getColumnCount();
			strColNm = new String[intColCnt];
			for (int i = 0; i < intColCnt; i++) {
				strColNm[i] = rMD.getColumnName(i + 1).toLowerCase();
			}
			intColCnt = strColNm.length;

			while (rs.next()) {
				for (int i = 0; i < intColCnt; i++) {
					result += " " + rs.getString(strColNm[i]);
				}
				result += " \n";
			}
			System.out.println("Return String : " + result);
			return result;
		}

		catch (SQLException ex) {
			return null;
		}
	}

	public String addCalendar(String account_name, String account_type, String name, String calendar_display_name) {
		// TODO Auto-generated method stub
		String result = null;
		Statement stmt = null;

		try {
			stmt = Database.Connector().createStatement();
			String sql = "";
			sql = "insert into t_calendar ( Calendar_NO, Account_Name, Account_type, Name, Calendar_Display_Name ) ";
			sql += "select ifnull(max(Calendar_NO),0) + 1,'" + account_name + "','" + account_type + "','" + name
					+ "', '" + calendar_display_name + "';";
			sql += "  from t_calendar ";

			System.out.println("Database.addUser insert sql : " + sql);

			stmt = Database.Connector().createStatement();
			rs = stmt.executeQuery(sql);

			result = getCalendar();
			return result;

		} catch (SQLException ex) {
			System.out.println("Database.addUserbefore SQLException");
			return null;
		} finally {
			System.out.println("Database.addUserbefore finally");
			try {
				rs.close();
			} catch (Exception ignored) {
			}
			try {
				stmt.close();
			} catch (Exception ignored) {
			}
			try {
				conn.close();
			} catch (Exception ignored) {
			}
		}
	}

	public String updateCalendar(String name, String calendar_no) {
		// TODO Auto-generated method stub
		String result = null;
		try {
			Statement stmt = Database.Connector().createStatement();
			rs = stmt.executeQuery("update t_calendar set name='" + name + "' calendar_no='" + calendar_no + "');");

			String[] strColNm = null;
			int intColCnt = 0;
			// ----------------------------------
			// resultSet의 메타이타를 가져온다.
			// ----------------------------------
			ResultSetMetaData rMD = rs.getMetaData();
			// ----------------------------------
			// 컬럼의 항목을 가져온다.
			// ----------------------------------
			intColCnt = rMD.getColumnCount();
			strColNm = new String[intColCnt];
			for (int i = 0; i < intColCnt; i++) {
				strColNm[i] = rMD.getColumnName(i + 1).toLowerCase();
			}
			intColCnt = strColNm.length;

			while (rs.next()) {
				for (int i = 0; i < intColCnt; i++) {
					result += " " + rs.getString(strColNm[i]);
				}
				result += " \n";
			}
			System.out.println("Return String : " + result);
			return result;
		}

		catch (SQLException ex) {
			return null;
		}
	}

	public String updateCalendar(String calendar_no) {
		// TODO Auto-generated method stub
		String result = null;
		try {
			Statement stmt = Database.Connector().createStatement();
			rs = stmt.executeQuery("update t_calendar set  calendar_no='" + calendar_no + "');");

			String[] strColNm = null;
			int intColCnt = 0;
			// ----------------------------------
			// resultSet의 메타이타를 가져온다.
			// ----------------------------------
			ResultSetMetaData rMD = rs.getMetaData();
			// ----------------------------------
			// 컬럼의 항목을 가져온다.
			// ----------------------------------
			intColCnt = rMD.getColumnCount();
			strColNm = new String[intColCnt];
			for (int i = 0; i < intColCnt; i++) {
				strColNm[i] = rMD.getColumnName(i + 1).toLowerCase();
			}
			intColCnt = strColNm.length;

			while (rs.next()) {
				for (int i = 0; i < intColCnt; i++) {
					result += " " + rs.getString(strColNm[i]);
				}
				result += " \n";
			}
			System.out.println("Return String : " + result);
			return result;
		}

		catch (SQLException ex) {
			return null;
		}
	}

	public String getEventList() {
		// TODO Auto-generated method stub
		String result = null;
		try {
			Statement stmt = Database.Connector().createStatement();
			rs = stmt.executeQuery("select * from t_event order by dtstart asc;");

			String[] strColNm = null;
			int intColCnt = 0;
			// ----------------------------------
			// resultSet의 메타이타를 가져온다.
			// ----------------------------------
			ResultSetMetaData rMD = rs.getMetaData();
			// ----------------------------------
			// 컬럼의 항목을 가져온다.
			// ----------------------------------
			intColCnt = rMD.getColumnCount();
			strColNm = new String[intColCnt];
			for (int i = 0; i < intColCnt; i++) {
				strColNm[i] = rMD.getColumnName(i + 1).toLowerCase();
			}
			intColCnt = strColNm.length;

			while (rs.next()) {
				for (int i = 0; i < intColCnt; i++) {
					result += " " + rs.getString(strColNm[i]);
				}
				result += " \n";
			}
			System.out.println("Return String : " + result);
			return result;
		}

		catch (SQLException ex) {
			return null;
		}

	}

	public String getEventList(String calendar_no) {
		// TODO Auto-generated method stub
		String result = null;
		try {
			Statement stmt = Database.Connector().createStatement();
			rs = stmt.executeQuery("select * from t_event where calendar_not="+calendar_no+"order by dtstart asc");

			String[] strColNm = null;
			int intColCnt = 0;
			// ----------------------------------
			// resultSet의 메타이타를 가져온다.
			// ----------------------------------
			ResultSetMetaData rMD = rs.getMetaData();
			// ----------------------------------
			// 컬럼의 항목을 가져온다.
			// ----------------------------------
			intColCnt = rMD.getColumnCount();
			strColNm = new String[intColCnt];
			for (int i = 0; i < intColCnt; i++) {
				strColNm[i] = rMD.getColumnName(i + 1).toLowerCase();
			}
			intColCnt = strColNm.length;

			while (rs.next()) {
				for (int i = 0; i < intColCnt; i++) {
					result += " " + rs.getString(strColNm[i]);
				}
				result += " \n";
			}
			System.out.println("Return String : " + result);
			return result;
		}

		catch (SQLException ex) {
			return null;
		}
	}

	public String getTodayEventList(String string, String string2) {
		// TODO Auto-generated method stub
		String result = null;
		try {
			Statement stmt = Database.Connector().createStatement();
			rs = stmt.executeQuery("select * from t_event dtstart order by dtstart asc");

			String[] strColNm = null;
			int intColCnt = 0;
			// ----------------------------------
			// resultSet의 메타이타를 가져온다.
			// ----------------------------------
			ResultSetMetaData rMD = rs.getMetaData();
			// ----------------------------------
			// 컬럼의 항목을 가져온다.
			// ----------------------------------
			intColCnt = rMD.getColumnCount();
			strColNm = new String[intColCnt];
			for (int i = 0; i < intColCnt; i++) {
				strColNm[i] = rMD.getColumnName(i + 1).toLowerCase();
			}
			intColCnt = strColNm.length;

			while (rs.next()) {
				for (int i = 0; i < intColCnt; i++) {
					result += " " + rs.getString(strColNm[i]);
				}
				result += " \n";
			}
			System.out.println("Return String : " + result);
			return result;
		}

		catch (SQLException ex) {
			return null;
		}
	}

	public String getEvent(String event_no) {
		String result = null;
		try {
			Statement stmt = Database.Connector().createStatement();
			rs = stmt.executeQuery("select * from t_event where event_no='"+event_no+"'");

			String[] strColNm = null;
			int intColCnt = 0;
			// ----------------------------------
			// resultSet의 메타이타를 가져온다.
			// ----------------------------------
			ResultSetMetaData rMD = rs.getMetaData();
			// ----------------------------------
			// 컬럼의 항목을 가져온다.
			// ----------------------------------
			intColCnt = rMD.getColumnCount();
			strColNm = new String[intColCnt];
			for (int i = 0; i < intColCnt; i++) {
				strColNm[i] = rMD.getColumnName(i + 1).toLowerCase();
			}
			intColCnt = strColNm.length;

			while (rs.next()) {
				for (int i = 0; i < intColCnt; i++) {
					result += " " + rs.getString(strColNm[i]);
				}
				result += " \n";
			}
			System.out.println("Return String : " + result);
			return result;
		}

		catch (SQLException ex) {
			return null;
		}

	}

	public String addEvent(String calendar_no, String title, String dtstart) {
		String result = null;
		Statement stmt = null;

		try {
			stmt = Database.Connector().createStatement();
			String sql = "";
			sql = "insert into t_event ( calendar_no, title, dtstart) ";
			sql += "select ifnull(max(calendar_no),0) + 1,'" + title + "','" +dtstart + "'";
			sql += "  from t_calendar ";

			System.out.println("Database.addUser insert sql : " + sql);

			stmt = Database.Connector().createStatement();
			rs = stmt.executeQuery(sql);

			result = getCalendar();
			return result;

		} catch (SQLException ex) {
			System.out.println("Database.addUserbefore SQLException");
			return null;
		} finally {
			System.out.println("Database.addUserbefore finally");
			try {
				rs.close();
			} catch (Exception ignored) {
			}
			try {
				stmt.close();
			} catch (Exception ignored) {
			}
			try {
				conn.close();
			} catch (Exception ignored) {
			}
		}
	}

	public String addEvent(String calendar_no, String title, String dtstart, String dtend) {
		// TODO Auto-generated method stub
		String result = null;
		Statement stmt = null;

		try {
			stmt = Database.Connector().createStatement();
			String sql = "";
			sql = "insert into t_event (calendar_no, title, dtstart, dtend) ";
			sql += "select ifnull(max(Calendar_NO),0) + 1,'" + title + "','" + dtstart + "','" + dtend + "';";
			sql += "  from t_calendar ";

			System.out.println("Database.addUser insert sql : " + sql);

			stmt = Database.Connector().createStatement();
			rs = stmt.executeQuery(sql);

			result = getCalendar();
			return result;

		} catch (SQLException ex) {
			System.out.println("Database.addUserbefore SQLException");
			return null;
		} finally {
			System.out.println("Database.addUserbefore finally");
			try {
				rs.close();
			} catch (Exception ignored) {
			}
			try {
				stmt.close();
			} catch (Exception ignored) {
			}
			try {
				conn.close();
			} catch (Exception ignored) {
			}
		}
	}

	public String updateEvent(String event_no, String title, String dtstart, String dtend) {
		// TODO Auto-generated method stub
		String result = null;
		try {
			Statement stmt = Database.Connector().createStatement();
			rs = stmt.executeQuery("update t_event set title='" + title + "' dtstart='" + dtstart + "' dtend='" +dtend+ "' where event_no'" +event_no+"');");

			String[] strColNm = null;
			int intColCnt = 0;
			// ----------------------------------
			// resultSet의 메타이타를 가져온다.
			// ----------------------------------
			ResultSetMetaData rMD = rs.getMetaData();
			// ----------------------------------
			// 컬럼의 항목을 가져온다.
			// ----------------------------------
			intColCnt = rMD.getColumnCount();
			strColNm = new String[intColCnt];
			for (int i = 0; i < intColCnt; i++) {
				strColNm[i] = rMD.getColumnName(i + 1).toLowerCase();
			}
			intColCnt = strColNm.length;

			while (rs.next()) {
				for (int i = 0; i < intColCnt; i++) {
					result += " " + rs.getString(strColNm[i]);
				}
				result += " \n";
			}
			System.out.println("Return String : " + result);
			return result;
		}

		catch (SQLException ex) {
			return null;
		}
	}

	public String deleteEvent(String event_no) {
		// TODO Auto-generated method stub
		String result = null;
		try {
			Statement stmt = Database.Connector().createStatement();
			rs = stmt.executeQuery( "delete from t_event where '"+ event_no+"'");

			String[] strColNm = null;
			int intColCnt = 0;
			// ----------------------------------
			// resultSet의 메타이타를 가져온다.
			// ----------------------------------
			ResultSetMetaData rMD = rs.getMetaData();
			// ----------------------------------
			// 컬럼의 항목을 가져온다.
			// ----------------------------------
			intColCnt = rMD.getColumnCount();
			strColNm = new String[intColCnt];
			for (int i = 0; i < intColCnt; i++) {
				strColNm[i] = rMD.getColumnName(i + 1).toLowerCase();
			}
			intColCnt = strColNm.length;

			while (rs.next()) {
				for (int i = 0; i < intColCnt; i++) {
					result += " " + rs.getString(strColNm[i]);
				}
				result += " \n";
			}
			System.out.println("Return String : " + result);
			return result;
		}

		catch (SQLException ex) {
			return null;
		}
	}

}