package dataBase;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import list.SinglyLinkedList;

public class DBManager {
	public static final String driver = "org.mariadb.jdbc.Driver";
	public static final String connection = "jdbc:mysql://localhost:3306/project";
	public static final String id = "root";
	public static final String pass = "0";

	private Connection conn = null;
	private Statement stmt = null;
	private ResultSet rs = null;

	private ConnectionManager connManager;

	public SinglyLinkedList playerList = new SinglyLinkedList();
	public String listResult = null;

	public void Connector() {
		try {
			connManager = new ConnectionManager(driver, connection, id, pass);
			conn = connManager.createConnection();
		} catch (SQLException e) {
			System.out.println("DB Connection Error + " + e);
			e.printStackTrace();
			connManager = null;
		}
	}

	public void InsertScore(String name, int Score) {
		stmt = null;
		String sql;

		try {
			Connector();
			stmt = conn.createStatement();
			rs = stmt.executeQuery("select * from diceplayer where name ='" + name + "';");

			if (rs.next()) {
				if (rs.getInt("score") < Score) {
					try {
						sql = "update diceplayer set score=" + Score + " where name='" + name + "';";
						stmt = conn.createStatement();
						stmt.executeUpdate(sql);
					} catch (SQLException sqex) {
						System.out.println("SQLException: " + sqex.getMessage());
						System.out.println("SQLState: " + sqex.getSQLState());
					}
				}
			} else {
				try {
					sql = "insert into diceplayer values('" + name + "'," + Score + ");";
					stmt = conn.createStatement();
					stmt.execute(sql);
				} catch (SQLException sqex) {
					System.out.println("SQLException: " + sqex.getMessage());
					System.out.println("SQLState: " + sqex.getSQLState());
				}
			}

		} catch (SQLException ex) {

		}

	}

	public void load() {
		stmt = null;

		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery("select * from diceplayer");
			String StrScore;
			playerList.clear();
			while (rs.next()) {
				String name = rs.getString(1);
				int score = rs.getInt(2);

				StrScore = String.valueOf(score);
				playerList.addLast("" + name + "\t" + StrScore);

			}
			listResult = playerList.toString();

		} catch (SQLException ex) {
		}
	}

	public boolean checkAccount(String ID, String PW) {
		stmt = null;

		try {
			
			stmt = conn.createStatement();
			rs = stmt.executeQuery("select * from account where ID='" + ID + "';");
			
			if (!rs.next()) {
				System.out.println("�ش� ID�� �������� �ʽ��ϴ�.");
				return false;
			}
			
			String tempPW = rs.getString(2);
			
			
			
			if (tempPW.equals(PW)) {
				System.out.println("�α��ο� �����Ͽ����ϴ�.");
				return true;
			} 
			else {
				System.out.println("��й�ȣ�� Ʋ�Ƚ��ϴ�.");
				return false;
			}
			
		} catch (SQLException ex) {

		}
		
		return false;
	}
}