package jnu.mcl.teamplication.model;

import java.util.ArrayList;

public class EventModelList {
    private static EventModelList newInstance;
    ArrayList<EventModel> List = new ArrayList<EventModel>();

    public static EventModelList getInstance() {
        if (newInstance == null) {
            newInstance = new EventModelList();
        }
        return newInstance;
    }

    public ArrayList<EventModel> getList(){
        return List;
    }
}