package jnu.mcl.teamplication.model;

import java.util.ArrayList;

public class CalendarModelList {
    private static CalendarModelList newInstance;
    ArrayList<CalendarModel> List = new ArrayList<CalendarModel>();

    public static CalendarModelList getInstance() {
        if (newInstance == null) {
            newInstance = new CalendarModelList();
        }
        return newInstance;
    }

    public ArrayList<CalendarModel> getList(){
        return List;
    }
}