package jnu.mcl.teamplication.service;

import android.util.Log;

import java.util.ArrayList;

import jnu.mcl.teamplication.client.UserClient;
import jnu.mcl.teamplication.listener.EventServiceListener;
import jnu.mcl.teamplication.model.EventModel;
import jnu.mcl.teamplication.model.EventModelList;

public class EventService {

    String host = "114.108.87.16";
    int port = 8082;
    public static int Calendar_NO;
    public static Long Now;
    public static Long TodayEnd;
    public static int Event_NO;
    public static String Title;
    public static String dtStart;
    public static String dtEnd;

    private ArrayList<EventServiceListener> eventServiceListeners;
    private static EventService newInstance;

    private EventService() {
        eventServiceListeners = new ArrayList<EventServiceListener>();
    }

    public static EventService getInstance() {
        if (newInstance == null) {
            newInstance = new EventService();
        }
        return newInstance;
    }

    public ArrayList<EventModel> getEventList() {
        ArrayList<EventModel> eventList = null;
        new Thread(new  Runnable(){
            @Override
            public void run(){
                try{
                    if(UserService.userclient ==null)
                        UserService.userclient = new UserClient(host, port);
                    UserService.userclient.sendToServer("$EventList");
                }catch(Exception e){}
            }
        }).start();
        try {
            System.out.println("EventList");
            eventList = new EventModelList().getInstance().getList();
            return eventList;
        } catch (Exception e) {
            Log.w("Error connection", e);
            return null;
        }
    }

    public ArrayList<EventModel> getEventList(final int calendar_no) {
        ArrayList<EventModel> eventList = null;
        Calendar_NO = calendar_no;
        new Thread(new  Runnable(){
            @Override
            public void run(){
                try{
                    if(UserService.userclient ==null)
                        UserService.userclient = new UserClient(host, port);
                    UserService.userclient.sendToServer("$$EventList_Calender_NO" + calendar_no);
                }catch(Exception e){}
            }
        }).start();
        try {
            System.out.println("EventList_Calendar_NO");
            eventList = new EventModelList().getInstance().getList();
            return eventList;
        } catch (Exception e) {
            Log.w("Error connection", e);
            return null;
        }
    }

    public ArrayList<EventModel> getTodayEventList(Long now, Long todayEnd) {
        ArrayList<EventModel> eventList = null;
        Now = now;
        TodayEnd = todayEnd;
        new Thread(new  Runnable(){
            @Override
            public void run(){
                try{
                    if(UserService.userclient ==null)
                        UserService.userclient = new UserClient(host, port);
                    //서버에서 now랑 todayEnd 쿼리문으로 처리
                    UserService.userclient.sendToServer("$$$EventList_Now" + Now+"!"+TodayEnd);
                }catch(Exception e){}
            }
        }).start();
        try {
            System.out.println("EventList_Now");
            eventList = new EventModelList().getInstance().getList();
            return eventList;
        } catch (Exception e) {
            Log.w("Error connection", e);
            return null;
        }
    }

    public EventModel getEvent(int event_no) {
        EventModel eventModel = null;
        Event_NO = event_no;
        new Thread(new  Runnable(){
            @Override
            public void run(){
                try{
                    if(UserService.userclient ==null)
                        UserService.userclient = new UserClient(host, port);
                    UserService.userclient.sendToServer("$GetEvent" + Event_NO);
                }catch(Exception e){}
            }
        }).start();
        try {
            System.out.println("GetEvent");
            eventModel = UserClient.eventModel;
            return eventModel;
        } catch (Exception e) {
            Log.w("Error connection", e);
            return null;
        }
    }

    public void addEvent(int calendar_no, String title, String dtstart) {
        Calendar_NO = calendar_no;
        Title = title;
        dtStart = dtstart;
        new Thread(new  Runnable(){
            @Override
            public void run(){
                try{
                    if(UserService.userclient ==null)
                        UserService.userclient = new UserClient(host, port);
                    UserService.userclient.sendToServer("$AddEvent1" + Calendar_NO +"!" + Title + "!" + dtStart);
                }catch(Exception e){}
            }
        }).start();
        try {
            System.out.println("AddEvent1");
        } catch (Exception e) {
            Log.w("Error connection", e);
        }
        notifyEventCreate();
    }

    public void addEvent(int calendar_no, String title, String dtstart, String dtend) {
        Calendar_NO = calendar_no;
        Title = title;
        dtStart = dtstart;
        dtEnd = dtend;
        new Thread(new  Runnable(){
            @Override
            public void run(){
                try{
                    if(UserService.userclient ==null)
                        UserService.userclient = new UserClient(host, port);
                    UserService.userclient.sendToServer("$$AddEvent2" + Calendar_NO +"!" + Title + "!" + dtStart + "!" +dtEnd);
                }catch(Exception e){}
            }
        }).start();
        try {
            System.out.println("AddEvent2");
        } catch (Exception e) {
            Log.w("Error connection", e);
        }
        notifyEventCreate();
    }

    public void updateEvent(int event_no, String title, String dtstart, String dtend){
        Event_NO = event_no;
        Title = title;
        dtStart = dtstart;
        dtEnd = dtend;
        new Thread(new  Runnable(){
            @Override
            public void run(){
                try{
                    if(UserService.userclient ==null)
                        UserService.userclient = new UserClient(host, port);
                    UserService.userclient.sendToServer("$UpdateEvent" + Event_NO +"!" + Title + "!" + dtStart + "!" +dtEnd);
                }catch(Exception e){}
            }
        }).start();
        try {
            System.out.println("UdateEvent");
        } catch (Exception e) {
            Log.w("Error connection", e);
        }
        notifyEventUpdate();
    }

    public void deleteEvent(int event_no){
        Event_NO = event_no;
        new Thread(new  Runnable(){
            @Override
            public void run(){
                try{
                    if(UserService.userclient ==null)
                        UserService.userclient = new UserClient(host, port);
                    UserService.userclient.sendToServer("$DeleteEvent" + Event_NO );
                }catch(Exception e){}
            }
        }).start();
        try {
            System.out.println("DeleteEvent");
        } catch (Exception e) {
            Log.w("Error connection", e);
        }
        notifyEventDelete();

    }

    public void addEventServiceListener(EventServiceListener calendarServiceListener) {
        if (!eventServiceListeners.contains(calendarServiceListener)) {
            eventServiceListeners.add(calendarServiceListener);
        }
    }

    public void notifyEventCreate() {
        for (EventServiceListener calendarServiceListener : eventServiceListeners) {
            calendarServiceListener.onEventCreate();
        }
    }

    public void notifyEventUpdate() {
        for (EventServiceListener calendarServiceListener : eventServiceListeners) {
            calendarServiceListener.onEventUpdate();
        }
    }

    public void notifyEventDelete() {
        for (EventServiceListener calendarServiceListener : eventServiceListeners) {
            calendarServiceListener.onEventDelete();
        }
    }
}
