package jnu.mcl.teamplication.listener;


public interface EventServiceListener {
    void onEventCreate();

    void onEventDelete();

    void onEventUpdate();
}
