package jnu.mcl.teamplication.service;

import android.util.Log;

import java.io.IOException;
import java.util.ArrayList;

import jnu.mcl.teamplication.client.UserClient;
import jnu.mcl.teamplication.listener.UserServiceListener;
import jnu.mcl.teamplication.model.UserModel;
import jnu.mcl.teamplication.model.UserModelList;

public class UserService {

    String host = "114.108.87.16";
    int port = 8082;
    public static UserClient userclient;
    public static  String ID;
    public static String Nickname;
    public static String Description;
    private ArrayList<UserServiceListener> userServiceListeners;
    private static UserService newInstance;
    private UserService() {
        userServiceListeners = new ArrayList<UserServiceListener>();
    }

    public static UserService getInstance() {
        if (newInstance == null) {
            newInstance = new UserService();
        }
        return newInstance;
    }

    //유저 목록 가져오기
    public ArrayList<UserModel> getUserList() {
        ArrayList<UserModel> userModelArrayList = null;
        new Thread(new  Runnable(){
            @Override
            public void run(){
                try{
                    if(userclient ==null)
                        userclient = new UserClient(host, port);
                    userclient.sendToServer("@UserList");

                }catch(Exception e){}
            }
        }).start();
        try {
            userModelArrayList = new UserModelList().getInstance().getList();
            return userModelArrayList;
        } catch (Exception e) {
            Log.w("Error connection", e);
            return null;
        }
    }

    //해당 유저 정보 가져오기
    public UserModel getUser(String id) throws IOException {
        UserModel userModel = null;
        ID = id;
        new Thread(new  Runnable(){
            @Override
            public void run(){
                try{
                    if(userclient ==null)
                        userclient = new UserClient(host, port);
                    userclient.sendToServer("@SignUp"+ID);
                }catch(Exception e){}
            }
        }).start();
        try {
            System.out.println("sign");
            userModel = UserClient.userModel;
            return userModel;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // id,nickname 유저 정보 가져오기
    public UserModel getUser(String id, String nickname) throws IOException {
        UserModel userModel = null;
        ID = id;
        Nickname = nickname;
        new Thread(new  Runnable(){
            @Override
            public void run(){
                try{
                    if(userclient ==null)
                        userclient = new UserClient(host, port);
                    userclient.sendToServer("@Login"+ID+"!"+Nickname);

                }catch(Exception e){}
            }
        }).start();
        try {
            System.out.println("login");
            userModel = UserClient.userModel;
            return userModel;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    //새로운 유저 추가하기
    public void addUser(String id, String nickname) {
        ID = id;
        Nickname = nickname;
        new Thread(new  Runnable(){
            @Override
            public void run(){
                try{
                    if(userclient ==null)
                        userclient = new UserClient(host, port);
                    userclient.sendToServer("@Add"+ID+"!"+Nickname);
                }catch(Exception e){}
            }
        }).start();
        try {
            System.out.println("add");
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    // 유저정보 업데이트
    public void updateUser(String id, String nickname, String description) {
        ID = id;
        Nickname = nickname;
        Description = description;
        new Thread(new  Runnable(){
            @Override
            public void run(){
                try{
                    if(userclient ==null)
                        userclient = new UserClient(host, port);
                    userclient.sendToServer("@Update"+ID+"!"+Nickname+"!"+Description);
                }catch(Exception e){}
            }
        }).start();
        try {
            System.out.println("update");
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        notifyUserUpdate();
    }

    public void addUserServiceListener(UserServiceListener userServiceListener) {
        if (!userServiceListeners.contains(userServiceListener)) {
            userServiceListeners.add(userServiceListener);
        }
    }

    public void notifyUserUpdate() {
        for (UserServiceListener userServiceListener : userServiceListeners) {
            userServiceListener.onUserUpdate();
        }
    }

}