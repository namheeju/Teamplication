package jnu.mcl.teamplication.model;

import java.util.ArrayList;

public class UserModelList {
    private static UserModelList newInstance;
    ArrayList<UserModel> List = new ArrayList<UserModel>();

    public static UserModelList getInstance(){
        if(newInstance == null){
            newInstance = new UserModelList();
        }
        return newInstance;
    }

    public ArrayList<UserModel> getList(){
        return List;
    }
}
