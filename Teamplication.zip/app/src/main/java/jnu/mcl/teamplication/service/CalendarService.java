package jnu.mcl.teamplication.service;

import android.util.Log;

import java.util.ArrayList;

import jnu.mcl.teamplication.client.UserClient;
import jnu.mcl.teamplication.listener.CalendarServiceListener;
import jnu.mcl.teamplication.model.CalendarModel;
import jnu.mcl.teamplication.model.CalendarModelList;

public class CalendarService {

    String host = "114.108.87.16";
    int port = 8082;
    public static int Calendar_NO;
    public static String Accout_Name;
    public static String Accout_Type;
    public static String Name;
    public static String Calendar_Display_Name;

    private ArrayList<CalendarServiceListener> calendarServiceListeners;
    private static CalendarService newInstance;

    private CalendarService() {
        calendarServiceListeners = new ArrayList<CalendarServiceListener>();
    }

    public static CalendarService getInstance() {
        if (newInstance == null) {
            newInstance = new CalendarService();
        }
        return newInstance;
    }

    public CalendarModel getCalendar(int calendar_no) {
        CalendarModel calendarModel = null;
        Calendar_NO = calendar_no;
        new Thread(new  Runnable(){
            @Override
            public void run(){
                try{
                    if(UserService.userclient ==null)
                        UserService.userclient = new UserClient(host, port);
                    UserService.userclient.sendToServer("#GetCalendar" + Calendar_NO);
                }catch(Exception e){}
            }
        }).start();
        try {
            System.out.println("GetCalendar");
            calendarModel = UserClient.calendarModel;
            return calendarModel;
        } catch (Exception e) {
            Log.w("Error connection", e);
            return null;
        }
    }

    public ArrayList<CalendarModel> getCalendarList() {
        ArrayList<CalendarModel> calendarList = null;
        new Thread(new  Runnable(){
            @Override
            public void run(){
                try{
                    if(UserService.userclient ==null)
                        UserService.userclient = new UserClient(host, port);
                    UserService.userclient.sendToServer("#CalendarList");
                }catch(Exception e){}
            }
        }).start();
        try {
            System.out.println("CalendarList");
            calendarList = new CalendarModelList().getInstance().getList();
            return calendarList;
        } catch (Exception e) {
            Log.w("Error connection", e);
            return null;
        }
    }

    public void addCalendar(final String account_name, final String account_type, final String name, final String calendar_display_name) {
        Accout_Name = account_name;
        Accout_Type = account_type;
        Name = name;
        Calendar_Display_Name = calendar_display_name;
        new Thread(new  Runnable(){
            @Override
            public void run(){
                try{
                    if(UserService.userclient ==null)
                        UserService.userclient = new UserClient(host, port);
                    UserService.userclient.sendToServer("#AddCalendar"+"!"+account_name+"!"+account_type+"!"+name+"!"+calendar_display_name);
                }catch(Exception e){}
            }
        }).start();
        try {
            System.out.println("AddCalendar");
        } catch (Exception e) {
            Log.w("Error connection", e);
        }
        notifyCalendarCreate();
    }

    public void updateCalendar(int calendar_no, String name){
        Calendar_NO = calendar_no;
        Name = name;
        new Thread(new  Runnable(){
            @Override
            public void run(){
                try{
                    if(UserService.userclient ==null)
                        UserService.userclient = new UserClient(host, port);
                    UserService.userclient.sendToServer("#UpdateCalendar"+"!"+Calendar_NO+"!"+Name);
                }catch(Exception e){}
            }
        }).start();
        try {
            System.out.println("UpdateCalendar");
        } catch (Exception e) {
            Log.w("Error connection", e);
        }
        notifyCalendarUpdate();
    }

    public void deleteCalendar(int calendar_no) {
        Calendar_NO = calendar_no;
        new Thread(new  Runnable(){
            @Override
            public void run(){
                try{
                    if(UserService.userclient ==null)
                        UserService.userclient = new UserClient(host, port);
                    UserService.userclient.sendToServer("#DeleteCalendar"+"!"+Calendar_NO);
                }catch(Exception e){}
            }
        }).start();
        try {
            System.out.println("DeleteCalendar");
        } catch (Exception e) {
            Log.w("Error connection", e);
        }
        notifyCalendarDelete();
    }

    public void addCalendarServiceListener(CalendarServiceListener calendarServiceListener) {
        if (!calendarServiceListeners.contains(calendarServiceListener)) {
            calendarServiceListeners.add(calendarServiceListener);
        }
    }

    public void notifyCalendarCreate() {
        for (CalendarServiceListener calendarServiceListener : calendarServiceListeners) {
            calendarServiceListener.onCalendarCreate();
        }
    }

    public void notifyCalendarDelete() {
        for (CalendarServiceListener calendarServiceListener : calendarServiceListeners) {
            calendarServiceListener.onCalendarDelete();
        }
    }

    public void notifyCalendarUpdate() {
        for (CalendarServiceListener calendarServiceListener : calendarServiceListeners) {
            calendarServiceListener.onCalendarUpdate();
        }
    }
}
