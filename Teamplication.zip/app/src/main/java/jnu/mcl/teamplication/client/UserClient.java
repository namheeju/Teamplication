package jnu.mcl.teamplication.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import jnu.mcl.teamplication.model.CalendarModel;
import jnu.mcl.teamplication.model.CalendarModelList;
import jnu.mcl.teamplication.model.EventModel;
import jnu.mcl.teamplication.model.EventModelList;
import jnu.mcl.teamplication.model.UserModel;
import jnu.mcl.teamplication.model.UserModelList;

public class UserClient extends AbstractClient {

    private boolean isLogin = false;
    public static UserModel userModel;
    public static EventModel eventModel;
    public static CalendarModel calendarModel;
    public static ArrayList<UserModel> userModelArrayList;
    public static ArrayList<EventModel> eventList;
    public static ArrayList<CalendarModel> calendarList;

    public UserClient(String host, int port) throws IOException {
        super(host, port);
        openConnection();
        System.out.println("connection");
        // TODO Auto-generated constructor stub
    }

    public void handleMessageFromServer(Object msg) {
        String s = msg.toString();
        String[] um;
        userModel = null;
        ArrayList<UserModel> userModelArrayList = null;
        eventModel = null;
        ArrayList<EventModel> eventList = null;
        calendarModel = null;
        ArrayList<CalendarModel> calendarList = null;
        if (s.startsWith("@UserList")) {
            s = s.substring(9);
            um = s.split(" ");
            userModelArrayList = new UserModelList().getInstance().getList();
            for(int i=0;i<um.length;i++) {
                userModel = new UserModel();
                userModel.setNo(Integer.parseInt(um[4*i]));
                userModel.setId(um[4*i+1]);
                userModel.setNickname(um[4*i+2]);
                userModel.setDescription(um[4*i+3]);
                userModelArrayList.add(userModel);
            }
        } else if (s.startsWith("@getUser_id")) {
            s = s.substring(11);
            um = s.split(" ");
            userModel = new UserModel();
            userModel.setNo(Integer.parseInt(um[0]));
            userModel.setId(um[1]);
            userModel.setNickname(um[2]);
            userModel.setDescription(um[3]);
        } else if (s.startsWith("@@gerUser_id_nickname")) {
            s = s.substring(21);
            um = s.split(" ");
            userModel = new UserModel();
            userModel.setNo(Integer.parseInt(um[0]));
            userModel.setId(um[1]);
            userModel.setNickname(um[2]);
            userModel.setDescription(um[3]);
        } else if(s.startsWith("$EventList")){
            s = s.substring(10);
            um = s.split(" ");
            eventList = new EventModelList().getInstance().getList();
            for(int i = 0;i < um.length;i++) {
                eventModel = new EventModel();
                eventModel.setEvent_no(Integer.parseInt(um[4*i]));
                eventModel.setTitle(um[4*i+1]);
                eventModel.setDtstart(um[4*i+2]);
                eventModel.setDtend(um[4*i+3]);
                eventList.add(eventModel);
            }
        } else if(s.startsWith("$GetEvent")){
            s = s.substring(9);
            um = s.split(" ");
            eventModel = new EventModel();
            eventModel.setEvent_no(Integer.parseInt(um[0]));
            eventModel.setTitle(um[1]);
            eventModel.setDtstart(um[2]);
            eventModel.setDtend(um[3]);
        } else if(s.startsWith("#GetCalendar")){
            s = s.substring(12);
            um = s.split(" ");
            calendarModel = new CalendarModel();
            calendarModel.setCalendar_no(Integer.parseInt(um[0]));
            calendarModel.setName(um[3]);
        } else if(s.startsWith("#CalendarList")){
            s = s.substring(13);
            um = s.split(" ");
            calendarList = new CalendarModelList().getInstance().getList();
            for(int i = 0;i<um.length;i++)  {
                calendarModel = new CalendarModel();
                calendarModel.setCalendar_no(Integer.parseInt(um[4*i]));
                calendarModel.setName(um[4*i+3]);
                calendarList.add(calendarModel);
            }
        }
    }

    public void handleMessageFromClientUI(String message) {
        try {
            sendToServer(message);
        } catch (IOException e) {
            System.out.println("서버에 메세지를 보낼 수 없습니다. 클라이언트를 종료합니다..");
            quit();
        }
    }

    public void accept() {
        try {
            BufferedReader fromConsole = new BufferedReader(
                    new InputStreamReader(System.in));
            String message;

            while (true) {
                message = fromConsole.readLine();
                handleMessageFromClientUI(message);
            }
        } catch (Exception ex) {
            System.out.println("Unexpected error while reading from console!");
        }
    }

    public void quit() {
        try {
            closeConnection();
        } catch (IOException e) {
        }
        System.exit(0);
    }
}


