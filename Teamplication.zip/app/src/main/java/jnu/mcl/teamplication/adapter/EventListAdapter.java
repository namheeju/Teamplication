package jnu.mcl.teamplication.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collection;

import jnu.mcl.teamplication.R;
import jnu.mcl.teamplication.model.EventModel;
import jnu.mcl.teamplication.util.DateFormatUtil;


public class EventListAdapter extends BaseAdapter {

    private ArrayList<EventModel> eventModels;
    private LayoutInflater inflater;

    public EventListAdapter(Context context) {
        this.inflater = LayoutInflater.from(context);
        this.eventModels = new ArrayList<>();
    }

    public void changeList(Collection<EventModel> newEventModels) {
        this.eventModels.clear();
        this.eventModels.addAll(newEventModels);
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return eventModels.size();
    }

    @Override
    public EventModel getItem(int position) {
        return eventModels.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        view = inflateIfRequired(view, position, parent);
        bind(getItem(position), view);
        return view;
    }

    private void bind(EventModel eventModel, View view) {
        ViewHolder viewHolder = (ViewHolder) view.getTag();

        String dtstart = "시작 : "+DateFormatUtil.utcToLocal(eventModel.getDtstart());
        String dtend = "";
        if(eventModel.getDtend()!=null){
            dtend = "종료 : "+DateFormatUtil.utcToLocal(eventModel.getDtend());
        }

        viewHolder.eventTitleText.setText(eventModel.getTitle());
        viewHolder.eventStartText.setText(dtstart);
        viewHolder.eventEndText.setText(dtend);
    }

    private View inflateIfRequired(View view, int position, ViewGroup parent) {
        if (view == null) {
            view = inflater.inflate(R.layout.event_item, null);
            view.setTag(new ViewHolder(view));
        }
        return view;
    }

    static class ViewHolder {
        final TextView eventTitleText;
        final TextView eventStartText;
        final TextView eventEndText;

        ViewHolder(View view) {
            eventTitleText = (TextView) view.findViewById(R.id.eventTitleText);
            eventStartText = (TextView) view.findViewById(R.id.eventStartText);
            eventEndText = (TextView) view.findViewById(R.id.eventEndText);
        }
    }

}
