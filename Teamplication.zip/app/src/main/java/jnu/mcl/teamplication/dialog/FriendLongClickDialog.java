package jnu.mcl.teamplication.dialog;

import android.app.Dialog;
import android.content.Context;
import android.view.Window;

import jnu.mcl.teamplication.R;

public class FriendLongClickDialog extends Dialog {

    public FriendLongClickDialog(Context context) {
        super(context);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_friend_long_click);
    }
}
