package jnu.mcl.teamplication.listener;


public interface CalendarServiceListener {
    void onCalendarCreate();

    void onCalendarDelete();

    void onCalendarUpdate();
}
