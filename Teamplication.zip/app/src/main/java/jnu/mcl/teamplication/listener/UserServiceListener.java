package jnu.mcl.teamplication.listener;


public interface UserServiceListener {

    void onUserUpdate();
}
