package jnu.mcl.teamplication.dialog;

import android.app.Dialog;
import android.content.Context;
import android.view.Window;
import android.widget.TextView;

import jnu.mcl.teamplication.R;


public class CustomLongClickDialog extends Dialog {

    private TextView modifyText, deleteText, copyText;

    public CustomLongClickDialog(Context context) {
        super(context);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_custom_long_click);

        modifyText = (TextView)findViewById(R.id.modifyText);
        deleteText = (TextView)findViewById(R.id.deleteText);
        copyText = (TextView)findViewById(R.id.copyText);
    }

    public TextView getModifyText(){
        return modifyText;
    }

    public TextView getDeleteText(){
        return deleteText;
    }

    public TextView getCopyText(){
        return copyText;
    }

}
